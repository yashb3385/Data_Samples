All 205 files listed below where created for [Bare Bones 3D Doors](https://modrinth.com/project/bare-bones-3d-doors) by [Hiveko](https://modrinth.com/user/Hiveko) under [GPL-3.0-only](https://spdx.org/licenses/GPL-3.0-only).



### Files



/assets/minecraft/textures/\*

/assets/rays\_3d\_rails/textures/\*

