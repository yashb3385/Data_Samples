Copied the below listed 189 files from [3D Default](https://modrinth.com/resourcepack/3d-default) by [GeForceLegend](https://modrinth.com/user/GeForceLegend) under [GPL-3.0-only](https://spdx.org/licenses/GPL-3.0-only).



### Files



/assets/minecraft/blockstates/\*

/assets/minecraft/models/block/\*

