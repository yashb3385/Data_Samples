#version 430

// unused (kept because files cannot be deleted in place); does nothing
layout (local_size_x = 1) in;

const ivec3 workGroups = ivec3(1, 1, 1);

void main() {}
